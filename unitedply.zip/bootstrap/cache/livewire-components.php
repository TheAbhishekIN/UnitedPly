<?php return array (
  'details' => 'App\\Http\\Livewire\\Details',
  'view-model' => 'App\\Http\\Livewire\\ViewModel',
);