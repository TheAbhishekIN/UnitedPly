<a href="/">
    <img src="<?php echo e(asset('images/logo_united_dark.png')); ?>" class="w-50 h-16" alt="">
</a>
<?php /**PATH C:\laragon\www\unitedply\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>