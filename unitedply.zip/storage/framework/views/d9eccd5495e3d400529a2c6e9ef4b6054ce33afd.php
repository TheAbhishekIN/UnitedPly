<footer class="footer-short">
    <div class="container">
      <hr>
      <nav class="row justify-content-between align-items-center">
        <div class="col-auto">
          <ul class="list-inline">
            <li class="list-inline-item">
              <a href="#">
                <img alt="Image" style="width: 9rem;height: auto;" src="<?php echo e(asset('images/logo_United_dark.png')); ?>">
              </a>
            </li>
            
          </ul>
        </div>
        <!--end of col-->
        <div class="col-auto text-sm-right">
          <ul class="list-inline">
            <li class="list-inline-item">
              <a href="#"><img src="<?php echo e(asset('images/icon/facebook.png')); ?>" height="25" alt="facebook"></a>
            </li>
            <li class="list-inline-item">
              <a href="#"><img src="<?php echo e(asset('images/icon/instagram.png')); ?>" height="25" alt="instagram"></a>
            </li>
          </ul>
        </div>
        <!--end of col-->
      </nav>
      <!--end of row-->
      <div class="row">
        <div class="col">
          <small>©<?php echo e(date('Y')); ?> SpeedUp Inc.</small>
        </div>
        <!--end of col-->
      </div>
      <!--end of row-->
    </div>
    <!--end of container-->
  </footer><?php /**PATH C:\laragon\www\unitedply\resources\views/inc/footer.blade.php ENDPATH**/ ?>