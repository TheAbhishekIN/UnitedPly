<div class="navbar-container">
  <div class="bg-dark navbar-dark" data-sticky="top">
    <div class="container">
      <nav class="navbar navbar-expand-lg">
        <a class="navbar-brand" href="">
          <img alt="Wingman" class="img-responsive" style="width: 9rem;height: auto;" src="<?php echo e(asset('images/logo_united.png')); ?>" />
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <i class="icon-menu h4"></i>
        </button>
        <div class="collapse navbar-collapse justify-content-between" id="navbarNav">
          <ul class="navbar-nav">
            <?php if(Auth::user()->role == 'admin'): ?>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-expanded="true">Catalog</a>
              <div class="dropdown-menu" aria-labelledby="pagesDropdown">

                <a class="dropdown-item" href="<?php echo e(route('admin.brands')); ?>">
                  <span class="h6 mb-0">Brands</span>
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="<?php echo e(route('admin.brands')); ?>">
                  <span class="h6 mb-0">Products</span>
                </a>
              </div>
            </li>
            <?php else: ?>
            <li class="nav-item">
              <a href="" class="nav-link">Catalog</a>
            </li>
            <?php endif; ?> 
            <?php if(Auth::user()): ?>
            <li class="nav-item">
              <a href="" class="nav-link">Price List</a>
            </li>
            <li class="nav-item">
              <a href="" class="nav-link">Invoice</a>
            </li>
            <?php endif; ?>
            <li class="nav-item">
              <a href="https://www.plyunited.com/about-company/" class="nav-link" target="_blank">About Us</a>
            </li>
          </ul>
          <ul class="navbar-nav">
            <?php if(auth()->guard()->check()): ?>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle dropdown-toggle-no-arrow p-lg-0" href="#" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <img alt="Image" src="assets/img/avatar-male-3.jpg" class="avatar avatar-xs">
                <span class="badge badge-danger">8</span>
              </a>
              <div class="dropdown-menu dropdown-menu-sm dropdown-menu-right" aria-labelledby="dropdown01">
                <a class="dropdown-item" href="#">Notifications <span class="badge badge-danger">8</span></a>
                <a class="dropdown-item" href="#">Profile</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">Settings</a>
                <a class="dropdown-item" href="#">Groups</a>
                <a class="dropdown-item" href="#">Log out</a>
              </div>
            </li>
            <?php else: ?>
            <li class="nav-item">
              <a href="<?php echo e(route('login')); ?>">Dealer Login</a>
            </li>
            <?php endif; ?>
          </ul>

        </div>
        <!--end nav collapse-->
      </nav>
    </div>
    <!--end of container-->
  </div>
</div><?php /**PATH C:\laragon\www\unitedply\resources\views/inc/navbar.blade.php ENDPATH**/ ?>